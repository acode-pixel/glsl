#ifndef DEBUG

#define DEBUG
void shaderCompilationCheck(unsigned int shader);
int programLinkCheck(unsigned int program);

#endif
