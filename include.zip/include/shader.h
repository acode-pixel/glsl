#ifndef SHADER_H
#define SHADER_H

#include <glad/glad.h>

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <debug.h>

class Shader
{
public:
	unsigned int ID;
	Shader(const char* vertexPath, const char* fragmentPath);
	const void use();
	const void setBool(const std::string &name, bool value);
	const void setInt(const std::string &name, int value);
	const void setFloat(const std::string &name, float value);
};

#endif

Shader::Shader(const char* vertexPath, const char* fragmentPath)
{

	std::string vertexCode;
	std::string fragmentCode;
	std::ifstream vShaderFile;
	std::ifstream fShaderFile;

	vShaderFile.exceptions (std::ifstream::failbit | std::ifstream::badbit);
	fShaderFile.exceptions (std::ifstream::failbit | std::ifstream::badbit);

	try {
		vShaderFile.open(vertexPath);
		fShaderFile.open(fragmentPath);
		std::stringstream vShaderStream, fShaderStream;
		vShaderStream << vShaderFile.rdbuf();
		fShaderStream << fShaderFile.rdbuf();
		vShaderFile.close();
		fShaderFile.close();
		vertexCode = vShaderStream.str();
		fragmentCode = fShaderStream.str();

	} catch (std::ifstream::failure e){
		std::cout << "ERROR: Failed reading shader files" << std::endl;
	}

	const char* vShaderCode = vertexCode.c_str();
	const char* fShaderCode = fragmentCode.c_str();

	unsigned int vertex, fragment;

	vertex = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertex, 1, &vShaderCode, NULL);
	glCompileShader(vertex);
	shaderCompilationCheck(vertex);

	fragment = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragment, 1, &fShaderCode, NULL);
	glCompileShader(fragment);
	shaderCompilationCheck(fragment);

	ID = glCreateProgram();
	glAttachShader(ID, vertex);
	glAttachShader(ID, fragment);
	glLinkProgram(ID);
	
	if(!programLinkCheck(ID)){
		std::cout << "ERROR: Program link failed";
	};

	glDeleteShader(vertex);
	glDeleteShader(fragment);
}

const void Shader::use() {
	glUseProgram(ID);
}
const void Shader::setBool(const std::string &name, bool value){
	glUniform1i(glGetUniformLocation(ID, name.c_str()), (int)value);
}
const void Shader::setInt(const std::string &name, int value){
	glUniform1i(glGetUniformLocation(ID, name.c_str()), value);
}
const void Shader::setFloat(const std::string &name, float value){
	glUniform1f(glGetUniformLocation(ID, name.c_str()), value);
}

